# Hi，以太坊

使用不同的方式接入以太坊。

在运行预置代码之前，请首先在1#终端启动节点仿真器：

```
~$ ganache-cli
```

## 使用命令行工具

在终端运行如下bash脚本：

```
~/repo/chapter2$ ./rpc-curl.sh
```

## 使用http库

在终端运行如下php脚本：

```
~/repo/chapter2$ php rpc-guzzle.php
```

## 使用web3.php开发包

在终端运行如下php脚本：

```
~/repo/chapter3$ php rpc-web3.php
```
